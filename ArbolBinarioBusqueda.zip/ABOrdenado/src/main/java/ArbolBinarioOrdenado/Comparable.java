package ArbolBinarioOrdenado;

public interface Comparable {
    public boolean esIgual(Object q);
    public boolean esMenor(Object q);
    public boolean esMayor(Object q);
}
